import './foodies-item.js';

class FoodiesList extends HTMLElement {

  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }

  set foodies(foodies) {
    this._foodies = foodies;
    this.render();
  }

  render() {
    this.shadowDOM.innerHTML = '';
    this._foodies.forEach(foodies => {
      const foodiesItemElement = document.createElement('foodies-item');
      foodiesItemElement.foodies = foodies;
      this.shadowDOM.appendChild(foodiesItemElement);
    });
  }

  renderError(message) {
    this.shadowDOM.innerHTML = `
      <style>
        .placeholder {
          font-weight: lighter;
          color: rgba(0,0,0,0.5);
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
        }
      </style>
    `;

    this.shadowDOM.innerHTML += `<h2 class="placeholder">${message}</h2>`;
  }
}

customElements.define('foodies-list', FoodiesList);